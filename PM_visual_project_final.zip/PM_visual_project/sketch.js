var signal;
var count = 0;
var angle = 0;
var colorShift = 0.1;
var colorShiftSwitch = false;
var particles = 50;
var img;
var imgs =[];
var signals = [];
var signals2 = [];
var current = 0;
var table;
var reading = [];
var readMax = 20; //test value
var readPos = 0;
var lastRead = 0;
var readReal = 1;
var backgroundR = 10;
var backgroundG =10;
var backgroundB =10;


function preload() {
    table = loadTable("airmote.csv", "csv", "header");
    for (var i = 0; i < 101; i++) {
      imgs[i] = loadImage("img/"+i+".jpg");
    }

}

function setup() {
    createCanvas(1000, 1000, WEBGL);
    var signal = new Signal();


    for (var i = 0; i < table.getRowCount(); i++) {
        var row = table.getRow(i);
        var x = row.get("PM1.5");

        reading[i] = x;
        console.log(reading[i]);
        readMax = i;
    }


}

function draw() {

background(backgroundR,backgroundG,backgroundB);


    if (lastRead == 0) {
        particles = 120;
        img = imgs[1];
    } else {

    }

    if (lastRead != int(reading[readPos])) {
        current = particles * (int(reading[readPos])+1);

        if (current < 3000) { //pass limit
            for (var i = 0; i < current; i++) {

                signals.push(new Signal());
                signals2.push(new Signal());

                //current = i;
                lastRead = int(reading[readPos]);

                if (lastRead > 99){
                img = imgs[100];//need 0 for array
              }

              else{
                img = imgs[lastRead];
              }
            }
        } else { //fail limit
            for (var i = 0; i < 3000; i++) {

                signals.push(new Signal());
                signals2.push(new Signal());

                lastRead = reading[readPos];

                if (lastRead > 99){
                img = imgs[100];//need 0 for array
              }
              else{
                img = imgs[lastRead];
              }

            }
        }
    } else {

    }

    pointLight(255, 0, 255, 200, 300, 100);
    ambientLight(30, 0, 52);

    push();
    camera(sin(frameCount * 0.01) * 100, sin(frameCount * 0.01) * 100, sin(frameCount * 0.01) * 100);
    for (var i = 0; i < signals.length; i++) {
        signals[i].show(colorShift, i, img, lastRead);
        signals[i].move(frameCount, angle, i);
    }
    pop();
    if (0.9 < signals.length - current) {
        for (var i = signals.length - current-1; i >= 0; i--) {
            var arrPos = signals.length - 1;
            signals.splice(arrPos, 1);
        }
    }
    camera(sin(frameCount * 0.01) * 100, sin(frameCount * 0.01) * 100, sin(frameCount * 0.01) * 100);
    push();
    for (var i = 0; i < signals2.length; i++) {
        signals2[i].show2(colorShift, i);
        signals2[i].move2(frameCount, angle, i);
    }
    pop();

    if (0.9 < signals2.length - current) {
        for (var i = signals2.length - current-1; i >= 0; i--) {
            var arrPos = signals2.length - 1;
            signals2.splice(arrPos, 1);
        }
    }

//testing info
    console.log("current");
    console.log(current);
    console.log("signal");
    console.log(signals.length);
    console.log("signal2");
    console.log(signals2.length);
    console.log("colorshift");
    console.log(colorShift);
    console.log(colorShiftSwitch);
    console.log(count);
    console.log(readPos);
    console.log(readMax);
//testing info

    angle += 0.002;



    //colotshift
    if (colorShift > 15) {
        colorShiftSwitch = true;
    }
    if (colorShift < 1) {
        colorShiftSwitch = false;
    }
    if (colorShiftSwitch) {
        colorShift -= 0.002;
    }
    if (!colorShiftSwitch) {
        colorShift += 0.002;
    }

    //count
    if (count > 3600) {

        if (readMax >= readPos) {
            readPos += 1;
        } else {
            readPos = 0;
        }
        count = 0;
    } else {
        count += 1;
    }


}
