function Signal() {
    // this.toDelete = false;
    this.show = function(colorShift, i, img, lastRead) {

        push();
        if (i == 1) {
            colorMode(HSB, 180, 150, 200);
            directionalLight(20, 250, 250, 4, 4, 0.25);
            ambientMaterial(100);
          //   specularMaterial(120,300,10);
              push();
              colorMode(HSB, 100, 10, 20);
              texture(img);
              directionalLight(57+lastRead*2, 20, 10, 10, 20, 0.5);
              rotateY(145);
              rotateZ(330);
              rotateX(160);
            sphere(105);
              pop();

        } else {

            translate(0, 0, -1500);

            directionalLight(2, 20, 20, 20, 4, 0.55);
            ambientMaterial(120, i / 8 * colorShift, 33 + i * colorShift);
            sphere(5);
        }

        pop();
    }
    this.show2 = function(angle, i) {

        push();

        translate(0, 0, -4000);
        sphere(65);

        pop();
    }




    this.move = function(frameCount, angle, i) {

        translate(-100, -150, 14);
        rotateZ(frameCount / 4 * 0.000015);
        rotateZ(frameCount / 2 * 0.0015);
        translate(i * 2, angle, 0);

    }

    this.move2 = function(frameCount, angle, i) {

        translate(0, 40, 210);
        rotateY(frameCount * -0.0018);
        rotateZ(frameCount * -0.00015);
        translate(0 + i * -13, 0, i);
        rotateY(frameCount * 0.001);
        rotateZ(frameCount * -0.0015);
        translate(i * -10, angle, 0);
        rotateX(i * -0.015);
        rotateY(angle * -0.06);


    }

}
