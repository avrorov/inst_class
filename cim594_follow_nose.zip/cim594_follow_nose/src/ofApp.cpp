#include "ofApp.h"

//this is a local function, so it doesn't need to be declared in the function. We use it with ofRemove

bool isDead( Particle &p ){
    if(p.life < 0) {
        return true;
    }
    else {
        return false;
    }
}

//--------------------------------------------------------------
void ofApp::setup(){
    soundStream.printDeviceList();
    
    //if you want to set a different device id
    //soundStream.setDeviceID(0); //bear in mind the device id corresponds to all audio devices, including  input-only and output-only devices.
    
    bool bNewFrame = false;
    
    cam.update();
    bNewFrame = cam.isFrameNew();
    if (bNewFrame){
        
        colorImg.setFromPixels(cam.getPixels());
        
        grayImage = colorImg;
        
        // take the abs value of the difference between background and incoming and then threshold:
        grayDiff.absDiff(grayBg, grayImage);
        grayDiff.threshold(threshold);
        
        // find contours which are between the size of 20 pixels and 1/3 the w*h pixels.
        // also, find holes is set to false so we won't get interior contours
        contourFinder.findContours(grayDiff, 20, (640*480)/3, 10, false);	// find holes
        
        
    }
    
    
    //for cam
    
    camWidth = 640;
    camHeight = 480;
    
    cam.setup(camWidth, camHeight);
    colorImg.allocate(640,480);
    grayImage.allocate(640,480);
    grayBg.allocate(640,480);
    grayDiff.allocate(640,480);
    
    threshold = 120;
    ofBackground(0);
    
}

//--------------------------------------------------------------
void ofApp::audioIn(float * input, int bufferSize, int nChannels){
    //RMS Algorithm. Get loudness of input.
    
//    float rms = 0.0;
//    int numCounted = 0;
//    for (int i = 0; i < bufferSize; i++) {
//        float leftSample = input[i * 2] * .5;
//        float rightSample = input[i * 2 + 1] * .5;
//        rms += leftSample * leftSample;
//        rms += rightSample * rightSample;
//        numCounted += 2;
//    }
//    
//    rms /= (float)numCounted;
//    rms = sqrt(rms);
//    loudness = rms;
  //    ofColor tmpColor = ofColor(ofRandom(255), ofRandom(255), ofRandom(255));
   // ofColor tmpColor = ofColor(int(rms), int(255*rms), ofRandom(255), int(255*rms));
 //   Particle myParticle;
 //   float vx = ofRandom(-20,20);
    //the downward trajectory is going to depend on how loud our input is
//    float vy = ofRandom(0,loudness*100);
 //   float vy = ofRandom(0,200);
   // myParticle.setInitialCondition(ofGetWidth()/2,ofGetHeight()/2,vx, vy);
   // myParticle.setInitialCondition(blobPosx,blobPosy,vx, vy);
//    myParticle.color = tmpColor;
    // more interesting with diversity :)
    // uncomment this:
//    myParticle.damping = ofRandom(0.01, 0.05);
 //   particles.push_back(myParticle);
  //  blobPosx

    
}

//--------------------------------------------------------------
void ofApp::update(){
    //remove particles if life has gone past 0
    ofRemove(particles, isDead);
    
    for (int i = 0; i < particles.size(); i++){
    //    particles[i].resetForce();
    //    particles[i].bounceOffWalls();
     //   particles[i].addDampingForce();
        particles[i].update();
    }
    
    //cam
    bool bNewFrame = false;
    
    cam.update();
    bNewFrame = cam.isFrameNew();
    if (bNewFrame){
        
        
        
        
        colorImg.setFromPixels(cam.getPixels());
        
        grayImage = colorImg;
        
        
        
        
        // take the abs value of the difference between background and incoming and then threshold:
        grayDiff.absDiff(grayBg, grayImage);
        grayDiff.threshold(threshold);
        
        // find contours which are between the size of 20 pixels and 1/3 the w*h pixels.
        // also, find holes is set to false so we won't get interior contours
        contourFinder.findContours(grayDiff, 20, (640*480)/3, 10, false);	// find holes
        
            for(int i = 0; i < particles.size(); i++) {
        //        particles[i].resetForce();
       //         particles[i].bounceOffWalls();
      //          particles[i].addDampingForce();
                
                particles[i].update();
           }
    }
    
}

//--------------------------------------------------------------
void ofApp::draw(){
   ofBackground(0, 0, 0);
    Particle myParticle;

    
    for(int i = 0; i < contourFinder.nBlobs; i++) {
        for(int j = 0; j < contourFinder.blobs[i].pts.size() - 1; j++) {
            ofDrawLine(contourFinder.blobs[i].pts[j], contourFinder.blobs[i].pts[j+1]);
        }

        
        myParticle.setInitialCondition(ofMap(contourFinder.blobs[i].centroid.x, 0, 640, 0, ofGetWidth()), ofMap(contourFinder.blobs[i].centroid.y, 0, 480, 0, ofGetHeight()), 0, 0);
        

   ofColor tmpColor = ofColor(ofRandom(255), ofRandom(255), ofRandom(255));
        myParticle.color = tmpColor;
 
        
        
         particles.push_back(myParticle);
        
    }
    for (int i = 0; i < particles.size(); i++){
        particles[i].draw();
    }
    
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){
    grayBg = grayImage;		// the = sign copys the pixels from grayImage into grayBg (operator overloading)
    
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){
    
}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){
    
}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){
    
}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){
    
}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){
    
}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){
    
}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 
    
}
