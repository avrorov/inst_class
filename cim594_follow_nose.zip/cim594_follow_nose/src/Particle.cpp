//
//  Particle.cpp
//  cim594_06_particle
//

// Example from Zach Lieberman, http://github.com/ofZach/algo2012
// https://github.com/ofZach/algo2012/tree/master/week4/drawingWithParticles

#include "Particle.hpp"


//------------------------------------------------------------
Particle::Particle(){
    setInitialCondition(30,30,30,30);
    damping = 0.01f;
    color = ofColor(255,255,255);
    a = 255;

    life = 200;
    
}

//------------------------------------------------------------
void Particle::setInitialCondition(float px, float py, float vx, float vy){
    pos.set(px,py);

    vel.set(vx,vy);

}

//------------------------------------------------------------
void Particle::update(){
//   vel = vel + frc;
    pos = pos + vel;
    life--;
}

//------------------------------------------------------------
void Particle::draw(){

     ofSetColor(color,255);
        ofDrawCircle(pos.x, pos.y,8);

    ofSetCircleResolution(90);
}

