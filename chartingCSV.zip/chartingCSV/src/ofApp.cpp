
#include "testApp.h"

//--------------------------------------------------------------
void testApp::setup(){
    
    if(csv.load("airmote.csv")) {
        ofLog(OF_LOG_NOTICE, "Data file loaded");
    }
    else {
        ofLog(OF_LOG_ERROR, "Unable to load data file");
    }
    //SKIP HEADER
    currentRow = 1;
    currentPM = 0;
    timeBetweenBroadcasts = 0.1;
    timer = ofGetElapsedTimef() + timeBetweenBroadcasts;
    ofBackground(0, 0, 0);
    
    //float rms = 0.0;
    int numCounted = 0;
    
    
    ofEnableSmoothing();
    ofEnableAlphaBlending();
    ofSetVerticalSync(true);
    ofSetFrameRate(60);
    ofBackground(22, 22, 22, 255);
    
    mouseIsPressed = false;
    int numSamples = 350;
    
    plot = new ofxHistoryPlot( NULL, "PM:", numSamples, false);
    plot->setRange(0, 100);
    plot->addHorizontalGuide(ofGetHeight()/2, ofColor(255,0,0));
    plot->setColor( ofColor(200,255,0) );
    plot->setShowNumericalInfo(true);
    plot->setRespectBorders(true);
    plot->setLineWidth(3);
    plot->setBackgroundColor(ofColor(0,240));
    
    plot->setDrawGrid(true);
    plot->setGridColor(ofColor(30));
    plot->setGridUnit(14);
    plot->setCropToRect(true);
    

}

//--------------------------------------------------------------
void testApp::update(){
    

    
    if(timer < ofGetElapsedTimef()) {
        timer = ofGetElapsedTimef() + timeBetweenBroadcasts;
        if(currentRow > csv.getNumRows()) {
            currentRow = 1;
            ofLog(OF_LOG_NOTICE, "Returning to row 0");
        }
        ofxCsvRow row;
        row = csv.at(currentRow);
        ofLog(OF_LOG_NOTICE, "Current PM: " + row.at(2));
        currentPM = ofToFloat(row.at(2));
         plot->update(currentPM);
        
        currentRow++;
        
        

        
        
    }
    
   
}

//--------------------------------------------------------------
void testApp::draw(){
    
    plot->draw(50, 50, 900, 500);
 
}

//--------------------------------------------------------------
void testApp::keyPressed(int key){
    
    plot->reset();
}

//--------------------------------------------------------------
void testApp::keyReleased(int key){
    
}

//--------------------------------------------------------------
void testApp::mouseMoved(int x, int y ){
    
}

//--------------------------------------------------------------
void testApp::mouseDragged(int x, int y, int button){
    
}

//--------------------------------------------------------------
void testApp::mousePressed(int x, int y, int button){
  //  mouseIsPressed = true;
    
}

//--------------------------------------------------------------
void testApp::mouseReleased(int x, int y, int button){
  //  mouseIsPressed = false;
}

//--------------------------------------------------------------
void testApp::windowResized(int w, int h){
    
}

//--------------------------------------------------------------
void testApp::gotMessage(ofMessage msg){
    
}

//--------------------------------------------------------------
void testApp::dragEvent(ofDragInfo dragInfo){ 
    
}
