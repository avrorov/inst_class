#include "ofApp.h"

//this is a local function, so it doesn't need to be declared in the function. We use it with ofRemove

bool isDead( Particle &p ){
    if(p.life < 0) {
        return true;
    }
    else {
        return false;
    }
}

//--------------------------------------------------------------
void ofApp::setup(){
    soundStream.printDeviceList();
    
    //if you want to set a different device id
    //soundStream.setDeviceID(0); //bear in mind the device id corresponds to all audio devices, including  input-only and output-only devices.
    
    int bufferSize = 256;
    
    
    soundStream.setup(this, 0, 2, 44100, bufferSize, 4);
    
    
    sounds[0].load("beast.wav");
    sounds[1].load("synth.wav");
    sounds[2].load("reverse.wav");
    sounds[3].load("doitlive.wav");
    sounds[4].load("sleigh-bells-hit.wav");
    sounds[5].load("sub_drum.wav");
    sounds[0].setMultiPlay(true);
    sounds[1].setMultiPlay(true);
    sounds[2].setMultiPlay(true);
    sounds[3].setMultiPlay(true);
    sounds[4].setMultiPlay(true);
    sounds[5].setMultiPlay(true);
    currentSound = 0;

}

//--------------------------------------------------------------
void ofApp::audioIn(float * input, int bufferSize, int nChannels){
    //RMS Algorithm. Get loudness of input.
    
    float rms = 0.0;
    int numCounted = 0;
    for (int i = 0; i < bufferSize; i++) {
        float leftSample = input[i * 2] * .5;
        float rightSample = input[i * 2 + 1] * .5;
        rms += leftSample * leftSample;
        rms += rightSample * rightSample;
        numCounted += 2;
    }
    
    rms /= (float)numCounted;
    rms = sqrt(rms);
    loudness = rms;
  //  ofColor tmpColor = ofColor(ofRandom(255), ofRandom(255), ofRandom(255));
        ofColor tmpColor = ofColor(int(rms), 74, ofRandom(255), int(255*rms));
    Particle myParticle;
    float vx = ofRandom(-20,20);
    //the downward trajectory is going to depend on how loud our input is
    float vy = ofRandom(0,loudness*500);
    myParticle.setInitialCondition(ofGetWidth()/2,ofGetHeight()/2,vx, vy);
    myParticle.color = tmpColor;
    // more interesting with diversity :)
    // uncomment this:
    myParticle.damping = ofRandom(0.001, 0.01);
    particles.push_back(myParticle);
}

//--------------------------------------------------------------
void ofApp::update(){
    //remove particles if life has gone past 0
    ofRemove(particles, isDead);
    
  
    
    
    for (int i = 0; i < particles.size(); i++){
        particles[i].resetForce();
        if(particles[i].bounceOffWalls() ) {
            sounds[2].setVolume(loudness);
             sounds[2].play();
        };
        particles[i].addDampingForce();
        particles[i].update();
    }
    
}

//--------------------------------------------------------------
void ofApp::draw(){
    ofBackground(0, 0, 0);
//The loudness is a very small number, to see it, we're going to map it with a much larger number of the screen width
    
    for (int i = 0; i < particles.size(); i++){
        particles[i].draw();
       
    }
    if (loudness > 0.17){
         sounds[1].play();
        
    }
    if (loudness > 0.1 && loudness < 0.12){
        sounds[1].play();
        
    }

}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){
    if(key == '1') {
        sounds[0].play();
    }
    if(key == '2') {
        sounds[1].play();
    }
    if(key == '3') {
        sounds[3].play();
    }
    //skip sound 2
    if(key == '4') {
        sounds[4].play();
    }


    

}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
